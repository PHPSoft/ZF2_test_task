<?php

namespace Application\Repository;

use Zend\Db\Adapter\AdapterAwareInterface;

interface RepositoryInterface extends AdapterAwareInterface
{

}